﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entidades
{
    public class Cocina
    {
        private int _codigo;
        private bool _esIndustrial;
        private double _precio;

        public int Codigo
        {
            get { return this._codigo; }
        }

        public bool EsIndustrial
        {
            get { return this._esIndustrial; }
        }

        public double Precio
        {
            get { return this._precio; }
        }

        public Cocina(int codigo,double precio,bool esIndustrial)
        {
            this._codigo = codigo;
            this._esIndustrial = esIndustrial;
            this._precio = precio;
        }

        public static bool operator ==(Cocina a, Cocina b)
        {
            return (a._codigo == b._codigo);
        }

        public static bool operator !=(Cocina a, Cocina b)
        {
            return !(a == b);
        }

        public override bool Equals(object obj)
        {
            bool retorno = false;
            if (obj is Cocina)
            {
                if ((Cocina)obj == (Cocina)obj)
                    retorno = true;
            }
            return retorno;
        }

        public override string ToString()
        {
            return "Codigo: " + this._codigo + " - Precio: " + this._precio + " - Es industrial? " + this._esIndustrial;
        }
    }
}
