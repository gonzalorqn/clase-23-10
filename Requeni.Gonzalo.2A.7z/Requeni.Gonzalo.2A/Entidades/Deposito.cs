﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entidades
{
    public class Deposito<T>
    {
        private int _capacidadMaxima;
        private List<T> _lista;

        public Deposito(int capacidad)
        {
            this._capacidadMaxima = capacidad;
            this._lista = new List<T>();
        }

        public static bool operator +(Deposito<T> d, T a)
        {
            return d.Agregar(a);
        }

        public bool Agregar(T a)
        {
            bool retorno = false;
            if (this._lista.Count < this._capacidadMaxima)
            {
                this._lista.Add(a);
                retorno = true;
            }
            return retorno;
        }

        private int GetIndice(T a)
        {
            int indice = -1;
            for (int i = 0; i < this._lista.Count; i++)
            {
                if (Object.Equals(this._lista[i],a))
                {
                    indice = i;
                    break;
                }
            }
            return indice;
        }

        public static bool operator -(Deposito<T> d, T a)
        {
            return d.Remover(a);
        }

        public bool Remover(T a)
        {
            bool retorno = false;
            if (this.GetIndice(a) > -1)
            {
                this._lista.RemoveAt(this.GetIndice(a));
                retorno = true;
            }
            return retorno;
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("Capacidad maxima: " + this._capacidadMaxima);
            sb.AppendLine("Listado de " + typeof (T));
            foreach (T t1 in this._lista)
            {
                sb.AppendLine(t1.ToString());
            }
            return sb.ToString();
        }
    }
}
