﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace Entidades
{
    public class DepositoDeCocinas
    {
        private int _capacidadMaxima;
        private List<Cocina> _lista;

        public DepositoDeCocinas(int capacidad)
        {
            this._capacidadMaxima = capacidad;
            this._lista = new List<Cocina>();
        }

        public static bool operator +(DepositoDeCocinas d, Cocina c)
        {
            return d.Agregar(c);
        }

        public bool Agregar(Cocina c)
        {
            bool retorno = false;
            if (this._lista.Count < this._capacidadMaxima)
            {
                this._lista.Add(c);
                retorno = true;
            }
            return retorno;
        }

        private int GetIndice(Cocina c)
        {
            int indice = -1;
            for (int i = 0; i < this._lista.Count; i++)
            {
                if (this._lista[i] == c)
                {
                    indice = i;
                    break;
                }
            }
            return indice;
        }

        public static bool operator -(DepositoDeCocinas d, Cocina c)
        {
            return d.Remover(c);
        }

        public bool Remover(Cocina c)
        {
            bool retorno = false;
            if (this.GetIndice(c) > -1)
            {
                this._lista.RemoveAt(this.GetIndice(c));
                retorno = true;
            }
            return retorno;
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("Capacidad maxima: " + this._capacidadMaxima);
            sb.AppendLine("Listado de cocinas");
            foreach (Cocina c1 in this._lista)
            {
                sb.AppendLine(c1.ToString());
            }
            return sb.ToString();
        }

        public bool Guardar(string path)
        {
            bool retorno;
            try
            {
                StreamWriter sw = new StreamWriter(path);
                sw.Write(this.ToString());
                sw.Close();
                retorno = true;
            }
            catch(DirectoryNotFoundException)
            {
                retorno = false;
            }
            return retorno;
        }

        public bool Recuperar(string path)
        {
            bool retorno;
            try
            {
                StreamReader sr = new StreamReader(path);
                sr.ReadToEnd();
                retorno = true; 
            }
            catch (DirectoryNotFoundException)
            {
                retorno = false;
            }
            return retorno;
        }
    }
}
